/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package anagram;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author NOUMAN SOOMRO
 */
public class Anagram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter first String :");
         String s1=sc.nextLine();
         System.out.print("Enter Second String :");
         String s2=sc.nextLine();
         List<String> matchedChar= new ArrayList<String>();
         int k=0;

        char[] ch1= s1.toLowerCase().toCharArray();
        char[] ch2= s2.toLowerCase().toCharArray();
         if(s1.length()==s2.length()){
             for(int i=0; i<s1.length(); i++){
                 for(int j=0; j<s2.length(); j++){
                     if(ch1[i]==ch2[j]){
                         k++;
                     }
                 }
             }
             if(k==s1.length()){
                 System.out.println("anagram");
             }else{
                 System.out.println("not anagram");
             }
         }
    }
    
}
