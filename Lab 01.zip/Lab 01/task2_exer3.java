/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsaclass;

/**
 *
 * @author User
 */
public class Dsaclass {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int arr[]=new int[6];
        
        arr[0]=3;
        arr[1]=6;
        arr[2]=9;
        arr[3]=12;
        arr[4]=15;
        int new1=18;
        arr[5]=new1;
        for(int i=0; i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }

    }
}
