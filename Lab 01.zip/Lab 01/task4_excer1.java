/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task4;

/**
 *
 * @author NOUMAN SOOMRO
 */
public class NewClass {
    
    public static void main(String[] args) {
        int arr[]={13,26,39,52,65};
        System.out.println("the element at index 4:"+arr[4]);
    }
    
}
