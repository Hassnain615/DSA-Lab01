/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task4;

/**
 *
 * @author NOUMAN SOOMRO
 */
public class NewClass1 {
    public static void main(String[] args) {
        int arr[]={4,6,2,8,10};
        int target=8;
        for(int i=0; i<arr.length; i++){
            if(arr[i]==target){
                System.out.println("Element "+target+" found at index "+i);
            }
        }
    }
    
}
