/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package task4;
import java.util.Scanner;
/**
 *
 * @author NOUMAN SOOMRO
 */
public class NewClass3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter String to check :");
        String name=sc.nextLine();
      
        if(name.charAt(0)==name.charAt(4)) {
            System.out.println("Palindrome");
        } else {
            System.out.println("not Palindrome");
        }
{

        }
    }
}
